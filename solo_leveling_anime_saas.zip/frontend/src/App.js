import React, { useState } from 'react';
import './App.css';
import animeLogo from './assets/anime_logo.png';

function App() {
    const [tasks, setTasks] = useState([
        { id: 1, name: "Push-ups", difficulty: "Easy", xp: 10, coins: 5 },
        { id: 2, name: "Run 2km", difficulty: "Medium", xp: 20, coins: 10 },
        { id: 3, name: "Cold Shower", difficulty: "Hard", xp: 30, coins: 15 },
    ]);
    const [xp, setXp] = useState(0);
    const [level, setLevel] = useState(1);
    const [coins, setCoins] = useState(0);

    const completeTask = (task) => {
        setXp(prevXp => {
            const newXp = prevXp + task.xp;
            if (newXp >= 100) {
                setLevel(prevLevel => prevLevel + 1);
                return 0;
            }
            return newXp;
        });
        setCoins(prevCoins => prevCoins + task.coins);
    };

    return (
        <div className="container">
            <img src={animeLogo} alt="Anime Logo" className="logo" />
            <h1 className="anime-text">Solo Leveling System</h1>
            <p>Level: {level} | XP: {xp}/100 | Coins: {coins}</p>
            <h2 className="anime-text">Tasks</h2>
            <ul className="task-list">
                {tasks.map(task => (
                    <li key={task.id} className="task-item">
                        {task.name} ({task.difficulty}) - XP: {task.xp}, Coins: {task.coins}
                        <button onClick={() => completeTask(task)}>Complete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default App;
